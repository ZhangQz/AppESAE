@extends('layouts.master')
@section('content')
	<div class="container-fluid">
		<div class="jumbotron">
			<h1>Esae - Pagina de Administrador</h1>
			<p>Pagina de administrador da aplicacao da Esae <strong>Desenvolvido por David Prata, Marco Silva e Zhang 15</strong> </p>
		</div>
	</div>
	
	
	
@endsection