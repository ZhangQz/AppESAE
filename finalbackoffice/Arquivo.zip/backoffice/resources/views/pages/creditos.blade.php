@extends('layouts.master')
@section('content')
	<div class="container-fluid">
		<h2>Exemplo criado por alunos do Instituto Superior Miguel Torga do curso de Multimédia</h2>
	</div>
@endsection
