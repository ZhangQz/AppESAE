
<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <h1>Lista de Cursos</h1>
    <p class="lead">Nesta página apresentamos uma lista de cursos registados na BD...</p>
    <br>
    <div class="container-fluid table-responsive">
      <table class="table table-hover">
        <thead>
          <tr>
            <th>Nome</th>
            <th>Tipo de Curso</th>
            <th>Responsavel</th>
            <th>Descrição</th>
            <th>Email</th>
            <th>ETCS</th>
             <th>Editar</th>
              <th>Relacoes</th>
              <th>Eliminar</th>


          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo $curso->nome; ?></td>
              <td><?php echo $curso->tipodecurso; ?></td>
              <td><?php echo $curso->responsavel; ?></td>
                <td><?php echo $curso->descricao; ?></td>
                  <td><?php echo $curso->email; ?></td>
                    <td><?php echo $curso->ects; ?></td>


              <!-- coluna de editar veículo -->
              <td>
                <a class="btn btn-default" href="<?php echo e(URL::route('curso.edit', $curso->id)); ?>"><img src="<?php echo e(asset('imagens/edit.png')); ?>" width="20" height="20"></a>
              </td>
              <td>
                <a class="btn btn-default" href="<?php echo e(URL::route('curso.show', $curso->id)); ?>"><img src="<?php echo e(asset('imagens/edit.png')); ?>" width="20" height="20"></a>
              </td>


              <!-- coluna de apagar veículo -->
              <td>
                <form action="<?php echo e(route('curso.destroy', $curso->id)); ?>" method="POST">
                  <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                  <input type="hidden" name="_method" value="DELETE">
                  <button type="submit" class="btn btn-danger">
                    <img src="<?php echo e(asset('imagens/delete.png')); ?>" width="20" height="20">
                  </button>
                </form>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <p><a href="<?php echo e(URL::route('curso.create')); ?>">Pretende adicionar mais um curso?</a></p>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>