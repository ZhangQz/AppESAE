
<?php $__env->startSection('content'); ?>
  <div class="container-fluid">

    <div class="container-fluid table-responsive">
      <table class="table table-hover">



       <thead>
          <tr>
            <th><h2>Nome das disciplinas do curso</h2></th>

          </tr>
       </thead>
       <tbody>

       <?php $__currentLoopData = $curso->disciplinas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disciplina): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tr>
       <td> <?php echo $disciplina->nome ;
?></td>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr><br>  </tbody>

     </table>



    <table class="table table-hover">

          <thead>
          <tr>
            <th><h2>Nome dos documentos do curso</h2></th>

          </tr>
       </thead>
       <tbody>

       <?php $__currentLoopData = $curso->documentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tr>
       <td> <?php echo $documento->nome ;
?></td>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr>  </tbody>

     </table>



      <table class="table table-hover">
          <thead>
          <tr>
            <th><h2>Nome dos eventos do curso</h2></th>

          </tr>
       </thead>
       <tbody>

       <?php $__currentLoopData = $curso->eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tr>
       <td> <?php echo $evento->nome
;
?><br></td>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tr>  </tbody>

      </table>





      <table class="table table-hover">
         <thead>
          <tr>
            <th><h2>Valor das propinas do curso</h2></th>

          </tr>
       </thead>
       <tbody>

       <?php $__currentLoopData = $curso->propinas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $propina): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tr>
       <td> <?php echo $propina->valor ;
?></td>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr>  </tbody>

       </table>



    <table class="table table-hover">
          <thead>
          <tr>
            <th><h2>Nome dos alunos do curso</h2></th>

          </tr>
       </thead>
       <tbody>

       <?php $__currentLoopData = $curso->utilizadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $utilizador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tr>
       <td> <?php echo $utilizador->nome ;
?></td>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr>  </tbody>

         </table>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>