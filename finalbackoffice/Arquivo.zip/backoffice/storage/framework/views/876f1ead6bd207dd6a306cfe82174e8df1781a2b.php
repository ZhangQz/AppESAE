<?php $__env->startSection('content'); ?>
	<div class="container-fluid">
		<h1>Editar cliente "<?php echo e($curso->id); ?>"</h1>
		<p class="lead">Edite a informação pretendida e carregue no botão guardar.</p>
		<hr>
		<form action="<?php echo e(route('curso.update', $curso->id)); ?>" method="POST">
			<input type="hidden" name="_method" value="PUT">
			
			
			<div class="form-group">
				<label for="id" class="control-label">Id:</label>
				<input type="text" id="id" name="id" class="form-control" value="<?php echo e($curso->id); ?>" readonly>
			</div>
			
			<div class="form-group">
				<label for="nome" class="control-label">Nome:</label>
				<input type="text" id="nome" name="nome" class="form-control" value="<?php echo e($curso->nome); ?>" required>
			</div>
			
			<div class="form-group">
				<label for="tipodecurso" class="control-label">Tipo de Curso:</label>
				<input type="text" id="tipodecurso" name="tipodecurso" class="form-control" value="<?php echo e($curso->tipodecurso); ?>" required>
			</div>
			
			<div class="form-group">
				<label for="responsavel" class="control-label">Respons�vel:</label>
				<input type="text" id="responsavel" name="responsavel" class="form-control" value="<?php echo e($curso->responsavel); ?>" required>
			</div>
			
			<div class="form-group">
				<label for="descricao" class="control-label">Descri��o:</label>
				<input type="text" id="descricao" name="descricao" class="form-control" value="<?php echo e($curso->descricao); ?>" required>
			</div>
			
			<div class="form-group">
				<label for="email" class="control-label">Email:</label>
				<input type="email" id="email" name="email" class="form-control" value="<?php echo e($curso->email); ?>" required>
			</div>
			
			<div class="form-group">
				<label for="telefone" class="control-label">Telefone:</label>
				<input type="number" id="telefone" name="telefone" class="form-control" value="<?php echo e($curso->telefone); ?>" required>
			</div>
			
			
			<input type="submit" value="Guardar" class="btn btn-primary">
			<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
		</form>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>