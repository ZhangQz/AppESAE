
<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <h1>Lista de Documentos</h1>
    <p class="lead">Nesta página apresentamos uma lista de Documentos registadas na BD...</p>
    <br>
    <div class="container-fluid table-responsive">
      <table class="table table-hover">
        <thead>
          <tr>
            <th>Id</th>
            <th>Nome</th>
            <th>Categoria</th>
            <th>Editar</th>
              <th>Relacoes</th>
              <th>Eliminar</th>
            
            
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $documentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo $documento->id; ?></td>
              <td><?php echo $documento->nome; ?></td>
              <td><?php echo $documento->categoria; ?></td>
             
             
                    
              <!-- coluna de editar veículo -->
              <td>
                <a class="btn btn-default" href="<?php echo e(URL::route('documento.edit', $documento->id)); ?>"><img src="<?php echo e(asset('imagens/edit.png')); ?>" width="20" height="20"></a>
            
            
              </td>
              
              <td>
                
            <a class="btn btn-default" href="<?php echo e(URL::route('documento.show', $documento->id)); ?>"><img src="<?php echo e(asset('imagens/edit.png')); ?>" width="20" height="20"></a>
            
              </td>

              <!-- coluna de apagar veículo -->
              <td>
                <form action="<?php echo e(route('documento.destroy', $documento->id)); ?>" method="POST">
                  <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                  <input type="hidden" name="_method" value="DELETE">
                  <button type="submit" class="btn btn-danger">
                    <img src="<?php echo e(asset('imagens/delete.png')); ?>" width="20" height="20">
                  </button>
                </form>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <p><a href="<?php echo e(URL::route('documento.create')); ?>">Pretende adicionar mais uma documento?</a></p>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>