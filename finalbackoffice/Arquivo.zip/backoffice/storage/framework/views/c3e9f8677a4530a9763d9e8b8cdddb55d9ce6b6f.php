<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    
    <div class="container-fluid table-responsive">
     <table class="table table-hover">
       
     
       
       <thead>
          <tr>
            <th><h2>Nome dos cursos que usam o documento</h2></th>
            
          </tr>
       </thead>
       <tbody>
       
       <?php $__currentLoopData = $documento->cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
       <tr>
       <td> <?php echo $curso->nome ;
?></td>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr><br>  </tbody>
    
     </table>
    </div>
   
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>