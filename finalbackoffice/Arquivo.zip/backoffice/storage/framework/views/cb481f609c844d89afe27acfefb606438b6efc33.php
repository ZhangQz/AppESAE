
<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
   
    <div class="container-fluid table-responsive">
      <table class="table table-hover">
        
        <tbody>
           
         <table class="table table-hover">
       
     
       
       <thead>
          <tr>
            <th><h2>Nome de cursos associados ao evento</h2></th>
            
          </tr>
       </thead>
       <tbody>
       
       <?php $__currentLoopData = $evento->cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
       <tr>
       <td> <?php echo $curso->nome ;
?></td>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr><br>  </tbody>
    
     </table>
      
      <table class="table table-hover">
       
     
       
       <thead>
          <tr>
            <th><h2>Nome das disciplinas associada ao evento</h2></th>
            
          </tr>
       </thead>
       <tbody>
       
       <?php $__currentLoopData = $evento->disciplinas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disciplina): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
       <tr>
       <td> <?php echo $disciplina->nome ;
?></td>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr><br>  </tbody>
    
     </table>
              
            </tr>
         
        </tbody>
      </table>
    </div>
    
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>