
<?php $__env->startSection('content'); ?>
	<div class="container-fluid">
		<div class="jumbotron">
			<h1>Esae - Pagina de Administrador</h1>
			<p>Pagina de administrador da aplicacao da Esae <strong>Desenvolvido por David Prata, Marco Silva e Zhang 15</strong> </p>
		</div>
	</div>
	
	
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>