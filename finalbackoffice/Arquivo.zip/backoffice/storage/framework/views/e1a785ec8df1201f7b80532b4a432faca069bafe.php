<?php $__env->startSection('content'); ?>
	<div class="container-fluid">
		<h1>Adicionar um novo curso com propina...</h1>
		<p class="lead">rqr.</p>
		<hr>
		<form action="<?php echo e(route('curso_propina.store')); ?>" method="POST">
			<div class="form-group">
				<label for="curso_id" class="control-label">Id do Curso:</label>
				<select id="curso_id" name="curso_id" class="form-control" required>
					<?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo $curso->id; ?>"><?php echo $curso->id; ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>

			<div class="form-group">
				<label for="propina_id" class="control-label">Id da propina:</label>
				<select id="propina_id" name="propina_id" class="form-control" required>
					<?php $__currentLoopData = $propinas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $propina): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo $propina->id; ?>"><?php echo $propina->id; ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>




			<input type="submit" value="Inserir nova propina" class="btn btn-primary">
			<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
		</form>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>