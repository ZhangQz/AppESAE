<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <h1>Lista de Users</h1>
    <p class="lead">Nesta página apresentamos uma lista de users registadas na BD...</p>
    <br>
    <div class="container-fluid table-responsive">
      <table class="table table-hover">
        <thead>
          <tr>
            <th>Id</th>
            <th>Numero</th>
            <th>Password</th>

          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo $user->id; ?></td>
              <td><?php echo $user->numero; ?></td>
               <td><?php echo $user->password; ?></td>




              <!-- coluna de editar veículo -->
              <td>
                <a class="btn btn-default" href="<?php echo e(URL::route('user.edit', $user->id)); ?>"><img src="<?php echo e(asset('imagens/edit.png')); ?>" width="20" height="20"></a>
              </td>

              <!-- coluna de apagar veículo -->
              <td>
                <form action="<?php echo e(route('user.destroy', $user->id)); ?>" method="POST">
                  <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                  <input type="hidden" name="_method" value="DELETE">
                  <button type="submit" class="btn btn-danger">
                    <img src="<?php echo e(asset('imagens/delete.png')); ?>" width="20" height="20">
                  </button>
                </form>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <p><a href="<?php echo e(URL::route('user.create')); ?>">Pretende adicionar mais um user?</a></p>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>